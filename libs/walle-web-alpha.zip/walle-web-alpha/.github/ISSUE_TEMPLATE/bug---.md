---
name: Bug 报告
about: 更详细的描述更利用问题解决
title: BUG
labels: bug
assignees: meolu

---

**问题描述**
在`角色`下，什么页面，什么功能，报错：xx
|在`super超管`角色下，项目管理页面，编辑项目成员，提交失败，报错：用户不存在于空间用户组中

**问题描述**
日志堆栈贴上来。
logs/runtime.log
```
runtime...
```
logs/error.log
```
error...
```

**截图**
拖拽到此处即可上传

**运行环境**
 - OS: [e.g. Centos 7.x]
 - 版本 [e.g. 2.0.0]
