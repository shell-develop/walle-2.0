import React from 'react';

export default () => (
  <div>
    404 Not Found
  </div>
);
